3D Game using OpenGL 3.3 with GLAD, GLFW, GLM, and SOIL Libraries

Used Minecraft like textures to render the world.

Direction Keys to control the character.

Additional Keys- 

q - Quit
1 - Rotating Chase Cam
2 - Chase Cam (Default Cam)
3 - Top View
4 - Tower View

The player is spawned at the starting position (i.e. at the left bottom) of a 30 x 30 grass field, full of lava and pits. The grass field is surround by water on all fronts. As of now, the player has to avoid the lava blocks and navigate through the field. Running over the lava blocks will respawn the player at the starting position.
